import React, { useRef, useState, useEffect } from 'react';
import ReactMarkdown from 'react-markdown';
import { Download, RefreshCw, CheckCircle2, FileDown, Share2, Trash2 } from 'lucide-react';
import { useParams, useNavigate } from 'react-router-dom';
import { AnalysisState, Report } from '../types';

// Declare html2pdf for TypeScript since it's loaded via CDN
declare var html2pdf: any;

interface ReportViewProps {
  analysis?: AnalysisState;
  onReset?: () => void;
}

const ReportView: React.FC<ReportViewProps> = ({ analysis: initialAnalysis, onReset }) => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const contentRef = useRef<HTMLDivElement>(null);
  
  const [analysis, setAnalysis] = useState<AnalysisState | null>(initialAnalysis || null);
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);
  const [isLoading, setIsLoading] = useState(!initialAnalysis);
  const [copyingLink, setCopyingLink] = useState(false);

  useEffect(() => {
    // If accessing via URL ID and no initial analysis provided, fetch it
    if (id && !initialAnalysis) {
      const fetchReport = async () => {
        try {
          const res = await fetch(`/api/reports/${id}`);
          if (res.ok) {
            const report: Report = await res.json();
            setAnalysis({
              status: 'COMPLETE' as any,
              result: report.result,
              error: null,
              fileName: report.fileName,
              reportId: report.id
            });
          } else {
            setAnalysis({
              status: 'ERROR' as any,
              result: null,
              error: "Report not found",
              fileName: null
            });
          }
        } catch (e) {
          console.error(e);
          setAnalysis({
            status: 'ERROR' as any,
            result: null,
            error: "Failed to load report",
            fileName: null
          });
        } finally {
          setIsLoading(false);
        }
      };
      fetchReport();
    }
  }, [id, initialAnalysis]);

  const handleDownloadMd = () => {
    if (!analysis?.result) return;
    const blob = new Blob([analysis.result], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `interview-analysis-${new Date().toISOString().slice(0, 10)}.md`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const handleDownloadPdf = async () => {
    if (!contentRef.current) return;
    setIsGeneratingPdf(true);
    
    const element = contentRef.current;
    const opt = {
      margin: [10, 10, 10, 10], // top, left, bottom, right
      filename: `BarRaiser_Report_${new Date().toISOString().slice(0, 10)}.pdf`,
      image: { type: 'jpeg', quality: 0.98 },
      html2canvas: { scale: 2, useCORS: true, logging: false },
      jsPDF: { unit: 'mm', format: 'a4', orientation: 'portrait' },
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
    };

    try {
      await html2pdf().set(opt).from(element).save();
    } catch (e) {
      console.error("PDF Generation failed", e);
      alert("Failed to generate PDF. You can try printing the page.");
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  const handleShare = async () => {
    const reportId = analysis?.reportId || id;
    if (!reportId) return;
    
    const url = `${window.location.origin}/report/${reportId}`;
    await navigator.clipboard.writeText(url);
    setCopyingLink(true);
    setTimeout(() => setCopyingLink(false), 2000);
  };

  const handleDelete = async () => {
    const reportId = analysis?.reportId || id;
    if (!reportId) return;
    
    if (!window.confirm("Are you sure you want to delete this report?")) return;

    try {
      const res = await fetch(`/api/reports/${reportId}`, { method: 'DELETE' });
      if (res.ok) {
        if (onReset) onReset();
        else navigate('/');
      }
    } catch (e) {
      console.error("Failed to delete", e);
    }
  };

  // Extract score from the text if possible
  const getOverallScore = (text: string) => {
    const match = text.match(/(?:综合建议|匹配结论)[：:]\s*\*\*?([A-Za-z+-]+)\*\*?/i);
    return match ? match[1] : 'N/A';
  };

  if (isLoading) {
    return <div className="text-center py-20 text-slate-500">Loading report...</div>;
  }

  if (!analysis || analysis.error) {
    return (
      <div className="max-w-xl mx-auto mt-20 text-center">
        <h3 className="text-xl font-bold text-slate-900">Report Not Found</h3>
        <p className="text-slate-500 mt-2 mb-6">{analysis?.error || "This report does not exist or has been deleted."}</p>
        <button onClick={() => navigate('/')} className="text-indigo-600 font-medium hover:underline">
          Go Home
        </button>
      </div>
    );
  }

  const score = analysis.result ? getOverallScore(analysis.result) : null;

  return (
    <div className="w-full max-w-5xl mx-auto animate-in fade-in slide-in-from-bottom-4 duration-500 pb-20">
      
      {/* Header Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
        <div>
          <h2 className="text-2xl font-bold text-slate-900 flex items-center gap-2">
            <CheckCircle2 className="w-6 h-6 text-green-500" />
            {id ? 'Assessment Report' : 'Assessment Complete'}
          </h2>
          <p className="text-slate-500 text-sm mt-1">
            Analysis for <span className="font-medium text-slate-700">{analysis.fileName}</span>
          </p>
        </div>
        
        <div className="flex flex-wrap items-center gap-3">
            {onReset && (
              <button 
                  onClick={onReset}
                  className="flex items-center gap-2 px-4 py-2 text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors shadow-sm"
              >
                  <RefreshCw className="w-4 h-4" />
                  New Analysis
              </button>
            )}
            
            {!onReset && (
              <button 
                  onClick={() => navigate('/')}
                  className="flex items-center gap-2 px-4 py-2 text-slate-600 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors shadow-sm"
              >
                  <RefreshCw className="w-4 h-4" />
                  New Analysis
              </button>
            )}

            <div className="h-6 w-px bg-slate-200 mx-1 hidden md:block"></div>

            <button 
                onClick={handleShare}
                className="flex items-center gap-2 px-4 py-2 text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors shadow-sm relative"
            >
                <Share2 className="w-4 h-4" />
                {copyingLink ? 'Copied!' : 'Share'}
            </button>

            <button 
                onClick={handleDownloadMd}
                className="flex items-center gap-2 px-4 py-2 text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg text-sm font-medium transition-colors shadow-sm"
            >
                <FileDown className="w-4 h-4" />
                Markdown
            </button>
            <button 
                onClick={handleDownloadPdf}
                disabled={isGeneratingPdf}
                className="flex items-center gap-2 px-4 py-2 text-white bg-indigo-600 hover:bg-indigo-700 rounded-lg text-sm font-medium transition-colors shadow-sm disabled:opacity-70 disabled:cursor-wait"
            >
                <Download className="w-4 h-4" />
                {isGeneratingPdf ? 'Generating...' : 'PDF'}
            </button>

            {(analysis.reportId || id) && (
              <button 
                  onClick={handleDelete}
                  className="flex items-center gap-2 px-3 py-2 text-red-600 bg-red-50 hover:bg-red-100 rounded-lg text-sm font-medium transition-colors shadow-sm ml-1"
                  title="Delete Report"
              >
                  <Trash2 className="w-4 h-4" />
              </button>
            )}
        </div>
      </div>

      {/* Main Content Area to be captured for PDF */}
      <div ref={contentRef} className="bg-white rounded-xl shadow-lg border border-slate-100 p-8 md:p-12">
        
        {/* Report Header (Visible in PDF) */}
        <div className="border-b border-slate-200 pb-6 mb-8 flex justify-between items-start">
            <div>
                <h1 className="text-3xl font-extrabold text-slate-900">Job Fit Assessment</h1>
                <p className="text-slate-500 mt-2">Generated by Bar Raiser AI Protocol</p>
            </div>
            {score && score !== 'N/A' && (
                <div className={`px-5 py-3 rounded-lg border text-center min-w-[120px]
                    ${score.includes('H+') || score === 'MH' ? 'bg-indigo-50 border-indigo-200 text-indigo-900' : 
                      score.includes('H') ? 'bg-green-50 border-green-200 text-green-900' :
                      'bg-amber-50 border-amber-200 text-amber-900'
                    }
                `}>
                     <div className="text-xs uppercase tracking-wider font-bold opacity-70 mb-1">Fit Level</div>
                     <div className="text-3xl font-black">{score}</div>
                </div>
            )}
        </div>

        {/* Custom Markdown Rendering with 4-Level Hierarchy */}
        <article className="prose prose-slate max-w-none">
          <ReactMarkdown
            components={{
                // Level 1: Main Sections (like "面试综述", "能力维度评估")
                h2: ({node, ...props}) => (
                    <h2 className="text-xl font-bold text-white bg-slate-800 px-4 py-2 rounded-lg mt-10 mb-6 flex items-center shadow-sm break-after-avoid" {...props} />
                ),
                // Level 2: Dimensions (like "维度一：坚韧抗压")
                h3: ({node, ...props}) => (
                    <h3 className="text-lg font-bold text-indigo-700 border-b-2 border-indigo-100 pb-2 mt-8 mb-4 break-after-avoid" {...props} />
                ),
                // Level 3: Sub-sections (STAR elements like "S (情境)")
                h4: ({node, ...props}) => (
                    <h4 className="text-base font-bold text-slate-800 uppercase tracking-wide bg-slate-50 border-l-4 border-indigo-500 pl-3 py-1 mt-6 mb-2 break-after-avoid" {...props} />
                ),
                // Body Text
                p: ({node, ...props}) => (
                    <p className="text-slate-600 leading-relaxed mb-4 text-base" {...props} />
                ),
                ul: ({node, ...props}) => (
                    <ul className="list-disc pl-5 space-y-2 mb-4 text-slate-600" {...props} />
                ),
                li: ({node, ...props}) => (
                    <li className="pl-1" {...props} />
                ),
                strong: ({node, ...props}) => (
                    <strong className="font-bold text-slate-900" {...props} />
                ),
                blockquote: ({node, ...props}) => (
                    <blockquote className="border-l-4 border-slate-300 pl-4 italic text-slate-500 my-4" {...props} />
                )
            }}
          >
            {analysis.result || ''}
          </ReactMarkdown>
        </article>
      </div>
      
      <div className="text-center mt-8 text-slate-400 text-xs">
          Confidential • Bar Raiser AI Assessment
      </div>
    </div>
  );
};

export default ReportView;
